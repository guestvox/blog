<?php

/******************************************************************************/
/******************************************************************************/

class PBUnit
{
	/**************************************************************************/

	function __construct() 
	{ 
		$this->unit=array
		(
			'%'																	=>	array(__('%',PLUGIN_PAGE_BUILDER_DOMAIN)),
			'in'																=>	array(__('in',PLUGIN_PAGE_BUILDER_DOMAIN)),
			'cm'																=>	array(__('cm',PLUGIN_PAGE_BUILDER_DOMAIN)),
			'mm'																=>	array(__('mm',PLUGIN_PAGE_BUILDER_DOMAIN)),
			'em'																=>	array(__('em',PLUGIN_PAGE_BUILDER_DOMAIN)),
			'ex'																=>	array(__('ex',PLUGIN_PAGE_BUILDER_DOMAIN)),
			'pt'																=>	array(__('pt',PLUGIN_PAGE_BUILDER_DOMAIN)),
			'pc'																=>	array(__('pc',PLUGIN_PAGE_BUILDER_DOMAIN)),
			'px'																=>	array(__('px',PLUGIN_PAGE_BUILDER_DOMAIN))
		);
	}

	/**************************************************************************/
}

/******************************************************************************/
/******************************************************************************/