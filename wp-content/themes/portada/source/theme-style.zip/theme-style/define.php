<?php

/******************************************************************************/
/******************************************************************************/

define('PLUGIN_THEME_STYLE_VERSION','3.9');

define('PLUGIN_THEME_STYLE_PATH',plugin_dir_path(__FILE__));
define('PLUGIN_THEME_STYLE_URL',plugins_url('theme-style'));

define('PLUGIN_THEME_STYLE_STYLE_PATH',PLUGIN_THEME_STYLE_PATH.'style/');
define('PLUGIN_THEME_STYLE_CLASS_PATH',PLUGIN_THEME_STYLE_PATH.'class/');

define('PLUGIN_THEME_STYLE_STYLE_URL',PLUGIN_THEME_STYLE_URL.'/style/');
define('PLUGIN_THEME_STYLE_SCRIPT_URL',PLUGIN_THEME_STYLE_URL.'/script/');

define('PLUGIN_THEME_STYLE_DOMAIN','theme-style');
define('PLUGIN_THEME_STYLE_CONTEXT','ts');
define('PLUGIN_THEME_STYLE_OPTION_NAME','ts');

/******************************************************************************/
/******************************************************************************/