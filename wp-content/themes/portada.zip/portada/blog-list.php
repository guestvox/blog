<?php 
		/* Template Name: Blog List */

		get_header(); 
		
		get_template_part('blog','content'); 

		get_footer(); 