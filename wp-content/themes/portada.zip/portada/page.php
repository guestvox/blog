<?php 
		/* Template Name: Page */

		get_header(); 
		
		get_template_part('page','content'); 

		get_footer(); 