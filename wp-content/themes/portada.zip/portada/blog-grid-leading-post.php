<?php 
		/* Template Name: Blog Grid With A Leading Post*/

		get_header(); 
		
		get_template_part('blog','content'); 

		get_footer(); 