Documentation of theme is located in folder "_documentation".
If you need more help, please use our Support Forum: http://support.quanticalabs.com/forum